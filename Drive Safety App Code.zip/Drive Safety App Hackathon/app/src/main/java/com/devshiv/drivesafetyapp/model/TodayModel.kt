package com.devshiv.drivesafetyapp.model

data class ItemModel(
    var title: String = "",
    var image: String = "",
    var link: String = "",
    var description: String = "",
)