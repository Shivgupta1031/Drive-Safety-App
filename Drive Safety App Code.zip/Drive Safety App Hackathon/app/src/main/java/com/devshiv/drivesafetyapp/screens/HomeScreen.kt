package com.devshiv.drivesafetyapp.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddAPhoto
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import coil.compose.AsyncImage
import com.devshiv.drivesafetyapp.App
import com.devshiv.drivesafetyapp.MainActivity
import com.devshiv.drivesafetyapp.R
import com.devshiv.drivesafetyapp.model.ItemModel
import com.devshiv.drivesafetyapp.ui.theme.AccentColor
import com.devshiv.drivesafetyapp.ui.theme.PrimaryDarkColor
import com.devshiv.drivesafetyapp.ui.theme.PrimaryDarkLightColor
import com.devshiv.drivesafetyapp.utils.AutoResizeText
import com.devshiv.drivesafetyapp.utils.Constants
import com.devshiv.drivesafetyapp.utils.FontSizeRange
import com.devshiv.drivesafetyapp.viewmodels.HomeViewModel

@Composable
fun HomeScreen(
    onNavigateRequired: (screen: String) -> Unit,
    onLogout: () -> Unit
) {
    val viewModel: HomeViewModel = hiltViewModel()

    val context = LocalContext.current as MainActivity

    val selectedTab by remember {
        mutableIntStateOf(0)
    }
    val userData by viewModel.userData.collectAsState()

    BackHandler(enabled = true) {
        context.finish()
    }

    val dataList: ArrayList<ItemModel> by remember {
        mutableStateOf(ArrayList())
    }

    dataList.add(
        ItemModel(
            "G-force and its role in harsh braking and acceleration",
            "https://safedrivesystems.com/blog/wp-content/uploads/2021/02/Blog-Header-4.jpg.webp",
            "https://safedrivesystems.com/blog/g-force-and-its-role-in-harsh-braking-and-acceleration/",
        )
    )
    dataList.add(
        ItemModel(
            "What is DVIR: The complete fleet managers’ guide (+ how to get more efficient with DVIR automation)",
            "https://cdn11.bigcommerce.com/s-5d127/images/stencil/300w/products/13035/16498/BAN215-MD__00597.1632151792.jpg",
            "https://safedrivesystems.com/blog/what-is-a-driver-vehicle-inspection-report/",
        )
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(PrimaryDarkColor)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(160.dp)
                .background(PrimaryDarkLightColor),
            verticalAlignment = Alignment.CenterVertically
        ) {

            Image(
                painter = painterResource(id = R.drawable.ic_profile),
                contentDescription = "Profile",
                modifier = Modifier
                    .fillMaxHeight()
                    .weight(0.4f)
                    .padding(20.dp)
                    .clip(RoundedCornerShape(40.dp)),
            )

            Column(
                modifier = Modifier
                    .fillMaxHeight()
                    .weight(0.6f)
                    .padding(top = 4.dp, start = 6.dp, end = 10.dp),
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    text = "Name : ${userData.name}",
                    style = MaterialTheme.typography.headlineMedium,
                    fontSize = 16.sp,
                    fontFamily = FontFamily(Font(R.font.main_font)),
                    fontWeight = FontWeight.Normal,
                    color = Color.White,
                    maxLines = 1,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Age : ${userData.age}",
                    style = MaterialTheme.typography.headlineMedium,
                    fontSize = 16.sp,
                    fontFamily = FontFamily(Font(R.font.main_font)),
                    fontWeight = FontWeight.Normal,
                    color = Color.White,
                    maxLines = 1,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Vehicle : ${userData.vehicle}",
                    style = MaterialTheme.typography.headlineMedium,
                    fontSize = 16.sp,
                    fontFamily = FontFamily(Font(R.font.main_font)),
                    fontWeight = FontWeight.Normal,
                    color = Color.White,
                    maxLines = 1,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(12.dp))
                Button(
                    onClick = {
                        onLogout()
                    },
                    modifier = Modifier
                        .padding(top = 4.dp, start = 20.dp, end = 20.dp, bottom = 4.dp)
                        .height(30.dp)
                        .align(Alignment.End),
                    elevation = ButtonDefaults.buttonElevation(6.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = AccentColor
                    ),
                    shape = RoundedCornerShape(4.dp),
                    contentPadding = PaddingValues(),
                ) {
                    Text(
                        text = "Logout",
                        fontSize = 16.sp,
                        fontFamily = FontFamily(Font(R.font.main_font)),
                        fontWeight = FontWeight.SemiBold,
                        color = Color.White,
                    )
                }
            }

        }

        Row(
            modifier = Modifier
                .padding(4.dp)
                .fillMaxWidth()
                .height(46.dp)
                .clip(RoundedCornerShape(6.dp))
                .background(PrimaryDarkLightColor),
            verticalAlignment = Alignment.CenterVertically
        ) {

            Text(
                modifier = Modifier
                    .weight(1f),
                text = "Cars",
                style = MaterialTheme.typography.headlineMedium,
                fontSize = if (selectedTab == 0) 19.sp else 16.sp,
                fontFamily = FontFamily(Font(R.font.main_font)),
                fontWeight = FontWeight.Normal,
                color = Color.White,
                textAlign = TextAlign.Center
            )

            Spacer(
                modifier = Modifier
                    .fillMaxHeight()
                    .width(2.dp)
                    .background(PrimaryDarkColor)
            )

            Text(
                modifier = Modifier
                    .weight(1f),
                text = "Motorbike",
                style = MaterialTheme.typography.headlineMedium,
                fontSize = if (selectedTab == 0) 19.sp else 16.sp,
                fontFamily = FontFamily(Font(R.font.main_font)),
                fontWeight = FontWeight.Normal,
                color = Color.White,
                textAlign = TextAlign.Center
            )

            Spacer(
                modifier = Modifier
                    .fillMaxHeight()
                    .width(2.dp)
                    .background(PrimaryDarkColor)
            )

            Text(
                modifier = Modifier
                    .weight(1f),
                text = "Truck",
                style = MaterialTheme.typography.headlineMedium,
                fontSize = if (selectedTab == 0) 19.sp else 16.sp,
                fontFamily = FontFamily(Font(R.font.main_font)),
                fontWeight = FontWeight.Normal,
                color = Color.White,
                textAlign = TextAlign.Center
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        LazyColumn(modifier = Modifier.weight(1f), content = {
            items(dataList) {
                ItemView(video = it) {

                }
            }
        })

        FloatingActionButton(
            onClick = {
                onNavigateRequired("${Constants.REPORT_ACCIDENT_NAV}/${Constants.HOME_NAV}/${App.curUser}")
            },
            modifier = Modifier
                .padding(16.dp)
                .size(56.dp)
                .align(Alignment.End)
        ) {
            Icon(
                imageVector = Icons.Default.AddAPhoto,
                contentDescription = "Report An Accident",
                tint = Color.White
            )
        }

    }
}

@Composable
fun ItemView(
    video: ItemModel,
    onItemClick: () -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(80.dp)
            .clickable { onItemClick() }
    ) {
        AsyncImage(
            model = video.image,
            contentDescription = null,
            contentScale = ContentScale.FillBounds,
            modifier = Modifier
                .width(140.dp)
                .fillMaxHeight()
                .padding(start = 12.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(AccentColor)
        )
        Column(
            modifier = Modifier
                .weight(1f)
        ) {
            AutoResizeText(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(0.7f)
                    .padding(start = 8.dp, end = 12.dp, top = 2.dp, bottom = 10.dp),
                text = video.title,
                fontFamily = FontFamily(Font(R.font.main_font)),
                fontWeight = FontWeight.Light,
                maxLines = 3,
                style = MaterialTheme.typography.titleSmall,
                color = Color.White,
                fontSizeRange = FontSizeRange(
                    min = 12.sp,
                    max = 14.sp,
                ),
                textAlign = TextAlign.Start,
            )
        }
    }

    Spacer(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 6.dp, bottom = 6.dp, start = 6.dp, end = 6.dp)
            .height(2.dp)
            .background(PrimaryDarkLightColor)
    )
}

@Preview(showSystemUi = true)
@Composable
fun PreviewHome() {
    HomeScreen({}, {})
}