package com.devshiv.drivesafetyapp.ui.theme

import androidx.compose.ui.graphics.Color

val PrimaryColor = Color(0xFF0D0D0D)
val PrimaryLightColor = Color(0xFF333333)
val PrimaryDarkColor = Color(0xFF000000)
val PrimaryDarkLightColor = Color(0xFF1A1A1A)

val AccentColor = Color(0xFF880E4F)
val AccentLightColor = Color(0xFFFF5472)